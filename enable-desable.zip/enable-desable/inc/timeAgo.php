<!-- php code -->
<?php
function timeAgo($time_ago){
date_default_timezone_set("Asia/Dhaka");
$cur_time 	= time();
$time_elapsed 	= $cur_time - $time_ago;
$seconds = $time_elapsed ;
$minutes 	= round($time_elapsed / 60 );
$hours 		= round($time_elapsed / 3600 );
$days 		= round($time_elapsed / 86400 );
$weeks 		= round($time_elapsed / 604800 );
$months 	= round($time_elapsed / 2600640 );
$years 		= round($time_elapsed / 31207680 );
// Seconds
if($seconds <= 60){
	    $engDATE = array('1','2','3','4','5','6','7','8','9','0');
		$bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০');
		$seconds = str_replace($engDATE, $bangDATE, $seconds);
	    echo "$seconds সেকেন্ড আগে";
}
//Minutes
else if($minutes <=60){
	if($minutes==1){
		echo "১ মিনিট আগে";
	}
	else{
		$engDATE = array('1','2','3','4','5','6','7','8','9','0');
		$bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০');
		$minutes = str_replace($engDATE, $bangDATE, $minutes);
		echo "$minutes মিনিট আগে";
	}
}
//Hours
else if($hours <=24){
	if($hours==1){
		echo "১ ঘন্টা আগে";
	}else{
		$engDATE = array('1','2','3','4','5','6','7','8','9','0');
		$bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০');
		$hours = str_replace($engDATE, $bangDATE, $hours);
		echo "$hours ঘন্টা আগে";
	}
}
//Days
else if($days <= 7){
	if($days==1){
		echo "গতকাল";
	}else{
		$engDATE = array('1','2','3','4','5','6','7','8','9','0');
		$bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০');
		$days = str_replace($engDATE, $bangDATE, $days);
		echo "$days দিন আগে";
	}
}
//Weeks
else if($weeks <= 4.3){
	if($weeks==1){
		echo "১ সপ্তাহ আগে";
	}else{
		$engDATE = array('1','2','3','4','5','6','7','8','9','0');
		$bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০');
		$weeks = str_replace($engDATE, $bangDATE, $weeks);
		echo "$weeks সপ্তাহ আগে";
	}
}
//Months
else if($months <=12){
	if($months==1){
		echo "১ মাস আগে";
	}else{
		$engDATE = array('1','2','3','4','5','6','7','8','9','0');
		$bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০');
		$months = str_replace($engDATE, $bangDATE, $months);
		echo "$months মাস আগে";
	}
}
//Years
else{
	if($years==1){
		echo "১ বছর আগে";
	}else{
		$engDATE = array('1','2','3','4','5','6','7','8','9','0');
		$bangDATE = array('১','২','৩','৪','৫','৬','৭','৮','৯','০');
		$years = str_replace($engDATE, $bangDATE, $years);
		echo "$years বছর আগে";
	}
}
}

?>
<!-- output -->
<?php
  // $curenttime = $row['date'];
  // $time_ago =strtotime($curenttime);
  // echo timeAgo($time_ago);
?>