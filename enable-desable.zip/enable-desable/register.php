<?php
 spl_autoload_register(function($class_name){
include "classes/".$class_name.".php";
});

$user = new User();
  
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['Register'])) {
$userRegi = $user->userRegistration($_POST);
}

?>

  
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Register</title>

    <!-- vendor css -->
    <link href="lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="lib/Ionicons/css/ionicons.css" rel="stylesheet">
    <link href="lib/select2/css/select2.min.css" rel="stylesheet">


    <!-- Starlight CSS -->
    <link rel="stylesheet" href="css/starlight.css">
  </head>

  <body>

    <div class="d-flex align-items-center justify-content-center bg-sl-primary ht-md-100v">
      <div class="login-content">

        <?php
        if (isset($userRegi)) {
          echo $userRegi;
        }

        ?>

      <div class="login-wrapper wd-300 wd-xs-400 pd-25 pd-xs-20 bg-white">
        <div class="signin-logo tx-center tx-24 tx-bold tx-inverse"><span class="tx-info tx-normal">Registration</span></div>
        <div class="tx-center mg-b-30"></div>
        <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">
        <div class="form-group">
          <input type="text" class="form-control" name="name" placeholder="Enter your fullname">
        </div><!-- form-group -->

        <div class="form-group">
          <input type="text" class="form-control" name="username" placeholder="Enter your username">
        </div><!-- form-group -->

        <div class="form-group">
          <input type="email" class="form-control" name="email" placeholder="Enter your Email">
        </div><!-- form-group -->
        
        <div class="form-group">
          <input type="password" class="form-control" name="password" placeholder="Enter your password">
        </div><!-- form-group -->
         
         <div class="form-group">
          <input type="hidden" class="form-control" name="role" value="0">
        </div><!-- form-group -->
         
        
        <button type="submit" class="btn btn-info btn-block" name="Register">Sign Up</button>
      </form>
        <div class="mg-t-40 tx-center">Already have an account? <a href="login.php" class="tx-info">Sign In</a></div>
      </div><!-- login-wrapper -->
     </div><!-- login-content -->
    </div><!-- d-flex -->

    <script src="lib/jquery/jquery.js"></script>
    <script src="lib/popper.js/popper.js"></script>
    <script src="lib/bootstrap/bootstrap.js"></script>
    <script src="lib/select2/js/select2.min.js"></script>
    <script>
      $(function(){
        'use strict';

        $('.select2').select2({
          minimumResultsForSearch: Infinity
        });
      });
    </script>

  </body>
</html>
