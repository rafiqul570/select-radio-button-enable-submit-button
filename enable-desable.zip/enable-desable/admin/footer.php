    <script src="../lib/jquery/jquery.js"></script>
    <script src="../lib/popper.js/popper.js"></script>
    <script src="../lib/bootstrap/bootstrap.min.js"></script>
    <script src="../lib/datatables/jquery.dataTables.js"></script>
    <script src="../lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js"></script>
    <script src="../lib/highlightjs/highlight.pack.js"></script>
    <script src="../lib/medium-editor/medium-editor.js"></script>
    <script src="../lib/summernote/summernote-bs4.min.js"></script>
    <script src="../js/starlight.js"></script>
    <script src="../js/main.js"></script>
   
  </body>
</html>
