<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>NEWSPAPER</title>
    <meta name="description" content="HTML5 Admin Template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- vendor css -->
    <link href="assets/lib/bootstrap5/assets/bootstrap.min.css" rel="stylesheet">
    <link href="assets/lib/font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.0/css/all.min.css">
    
    <!--Custom css -->
    <link rel="stylesheet" href="css/custom.css">
    
    </head>
    <body>
        <div class="container">
            <div class="row">
               <form action="" method="POST"> 
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="userRoles" id="radio-group1" value="Radio1">
                  <label class="form-check-label" for="flexRadioDefault1">
                    Radio1
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="userRoles" id="radio-group2" value="Radio2">
                  <label class="form-check-label" for="flexRadioDefault1">
                    Radio2
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="userRoles" id="radio-group3" value="Radio3">
                  <label class="form-check-label" for="flexRadioDefault1">
                    Radio3
                  </label>
                </div>
                <div class="form-check">
                  <input class="form-check-input" type="radio" name="userRoles" id="radio-group4" value="Radio4">
                  <label class="form-check-label" for="flexRadioDefault1">
                    Radio4
                  </label>
                </div>
                <input type="submit" name="submit" id="letsCook" value="Next" disabled>
               </form> 
            </div>
        </div>
         

    <!-- =====JQUERY==== -->
    <script id="dsq-count-scr" src="//newsportal-8.disqus.com/count.js" async></script>
    <script src="assets/lib/jquery/jquery.js"></script>
    <script src="assets/lib/bootstrap5/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/main.js"></script>


    <script>
        var inputGroup = document.querySelector('#radio-group1');
        var letsCookButton = document.querySelector('#letsCook');
        inputGroup.addEventListener('click', function () {
        letsCookButton.removeAttribute('disabled')
        });

        var inputGroup = document.querySelector('#radio-group2');
        var letsCookButton = document.querySelector('#letsCook');
        inputGroup.addEventListener('click', function () {
        letsCookButton.removeAttribute('disabled')
        });
        var inputGroup = document.querySelector('#radio-group3');
        var letsCookButton = document.querySelector('#letsCook');
        inputGroup.addEventListener('click', function () {
        letsCookButton.removeAttribute('disabled')
        });
        var inputGroup = document.querySelector('#radio-group4');
        var letsCookButton = document.querySelector('#letsCook');
        inputGroup.addEventListener('click', function () {
        letsCookButton.removeAttribute('disabled')
        });

    </script>

    </body>
    </html>